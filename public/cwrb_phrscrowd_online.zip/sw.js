/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "screenshot-mobile.png",
    "revision": "ed07a40edc4d97a795c686f73a8eb44c"
  }, {
    "url": "screenshot-desktop.png",
    "revision": "ed07a40edc4d97a795c686f73a8eb44c"
  }, {
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "mockup_admin_toggles.html",
    "revision": "545ecdb191da482116f3190b82722c8e"
  }, {
    "url": "mockup9.html",
    "revision": "4641d8374f6004dfbbc6faaf21d201cc"
  }, {
    "url": "mockup8.html",
    "revision": "6c8d19bf30f61e356cba6b5d22d55e2f"
  }, {
    "url": "mockup7.html",
    "revision": "fadfe2c0833858dd339459b8f119c5a9"
  }, {
    "url": "mockup6.html",
    "revision": "2b43fe48880d7898c146b00b74f77260"
  }, {
    "url": "mockup5.html",
    "revision": "16074e1858f2055938bdd7541d15501d"
  }, {
    "url": "mockup4.html",
    "revision": "9c70059db73c2d0cbedc41767bbb1ad9"
  }, {
    "url": "mockup3.html",
    "revision": "dcdbbbf07291ee91714deed73558ae33"
  }, {
    "url": "mockup2.html",
    "revision": "3a2e291f8342e7152a21efe354a2ea69"
  }, {
    "url": "mockup12.html",
    "revision": "f534dfebcab5a79c460ff295f6248a88"
  }, {
    "url": "mockup11.html",
    "revision": "4689b16c7fe4467a222691551aeb6f17"
  }, {
    "url": "mockup10.html",
    "revision": "8ea7db52735d9aaa2cfb3798299f7e7c"
  }, {
    "url": "mockup.html",
    "revision": "6a69c17cc96fb8ab0bac4d2e114b9cea"
  }, {
    "url": "mockup-splash.html",
    "revision": "da840b5554d875ebf5b44d161ea633b4"
  }, {
    "url": "mockup-splash-zoom.html",
    "revision": "097177649d82cae6521ad737161bac81"
  }, {
    "url": "mockup-splash-zoom-out.html",
    "revision": "5976b5154a970475bf59d5f9f194d205"
  }, {
    "url": "mockup-splash-scale-90.html",
    "revision": "8f9fa6a4e098a569f04ab3c4278c2e4a"
  }, {
    "url": "mockup-splash-scale-85.html",
    "revision": "9c610e12e7f141ce21d190c8f7ae9307"
  }, {
    "url": "mockup-scales.html",
    "revision": "5504aca2659f4a96b829421364295219"
  }, {
    "url": "manifest.json",
    "revision": "06992df519b0b5d4647cd082cc90d776"
  }, {
    "url": "index.html",
    "revision": "34695dcb0e384b3b7d7f3faea940dacb"
  }, {
    "url": "icon.png",
    "revision": "f2c93ad35bc2501ee1aadab6c5a706bd"
  }, {
    "url": "icon-96.png",
    "revision": "6e278318a09c2019561325fb8ec25900"
  }, {
    "url": "icon-512.png",
    "revision": "f2c93ad35bc2501ee1aadab6c5a706bd"
  }, {
    "url": "icon-384.png",
    "revision": "8e7e5795d2450a9711d897e0db09cf69"
  }, {
    "url": "icon-256.png",
    "revision": "1b8358af4da57e3ef22395b2154874bd"
  }, {
    "url": "icon-192.png",
    "revision": "f2c93ad35bc2501ee1aadab6c5a706bd"
  }, {
    "url": "icon-144.png",
    "revision": "ce251435e29a7bd90cca4616251efe1e"
  }, {
    "url": "cwrb-logo.png",
    "revision": "f2c93ad35bc2501ee1aadab6c5a706bd"
  }, {
    "url": "assets/logo-Dvs8eh3-.png",
    "revision": null
  }, {
    "url": "assets/index-j6QqVHX_.css",
    "revision": null
  }, {
    "url": "assets/index-C564hwH3.js",
    "revision": null
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
